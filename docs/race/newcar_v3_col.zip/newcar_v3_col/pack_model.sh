$PACKER_DIR pack-moby-model -i . -o . -v 3
